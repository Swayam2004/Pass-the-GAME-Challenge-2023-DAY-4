using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Waypoint : MonoBehaviour
{
    // Please add a Waypoint system if you know how to do it



    /* // This is a reference to the player or the object that needs to navigate between waypoints.
    public Transform target;

    // This is the distance threshold within which the waypoint is considered "reached".
    public float waypointReachedDistance = 1f;

    // This is the radius within which the waypoint will be shown on the screen.
    public float waypointScreenRadius = 50f;

    private void Start()
    {
        target = Camera.main.transform;
    } */
}
